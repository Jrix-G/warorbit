from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict

from neural_network.src.model import ModelConfig, NeuralNetworkModel, load_compatible_state_dict
from neural_network.src.notebook_4p_training import _infer_input_dim, _make_policy_agent
from neural_network.src.storage import load_checkpoint


ROOT = Path(__file__).resolve().parent
CHECKPOINT_PATH = ROOT / "best_validated.npz"
CONFIG_PATH = ROOT / "config.json"


def _load_config() -> Dict[str, Any]:
    if CONFIG_PATH.exists():
        with CONFIG_PATH.open("r", encoding="utf-8") as f:
            config = json.load(f)
    else:
        config = {}
    config.setdefault("policy_prior_strength", 0.55)
    config.setdefault("send_ratios", [0.25, 0.35, 0.5, 0.65, 0.8, 0.95])
    config.setdefault("min_expand_attack_ships", 6)
    config.setdefault("max_actions_per_turn", 4)
    config.setdefault("hidden_dim", 320)
    config.setdefault("seed", 42)
    return config


@lru_cache(maxsize=1)
def _build_agent():
    config = _load_config()
    input_dim = _infer_input_dim(config)
    model = NeuralNetworkModel(ModelConfig(input_dim=input_dim, hidden_dim=int(config.get("hidden_dim", 320))))
    state, _metadata = load_checkpoint(CHECKPOINT_PATH)
    load_compatible_state_dict(model, state)
    model.eval()
    return _make_policy_agent(model, config, temperature=0.0, explore=False)


def agent(obs, config=None):
    return _build_agent()(obs, config)

