# Dossier War Orbit V9

Contenu inclus dans le zip:
- `PROMPT.md`
- `README.md`
- `CLAUDE.md`
- `bot_v9.py`
- `run_v9.py`
- `test_v9_robustness.py`
- `war_orbit/config/v9_config.py`
- `war_orbit/agents/v9/__init__.py`
- `war_orbit/agents/v9/policy.py`
- `war_orbit/agents/v9/planner.py`
- `war_orbit/agents/v9/adaptation.py`
- `war_orbit/agents/v9/evaluator.py`
- `war_orbit/training/trainer.py`
- `war_orbit/training/curriculum.py`
- `war_orbit/evaluation/benchmark.py`
- `docs/specs/V9_ARCHITECTURE.md`
- `logs/v9_train_1h_15agents_20260503_174700.log`
- `logs/v9_frontfix_60min_20260503_191423.log`
- `logs/v9_backbone_60min_20260503_205231.log`
- `logs/logsfromVPS/v9_robust_train.jsonl`
- `logs/logsfromVPS/v9_15agents_1h_train.jsonl`

But:
- fournir un dossier compact mais suffisant pour diagnostiquer le 4p
- inclure des fichiers d’architecture et de logs, pas tout le dépôt
