# Analyse demandée: War Orbit V9

Tu es un expert en analyse de bots de compétition et en diagnostics de performance multi-joueurs.

Contexte:
- Le projet contient `bot_v9`, un bot Orbit Wars/Kaggle.
- Il performe correctement en 2p mais chute fortement en 4p.
- Les derniers logs montrent souvent un `winrate` 4p autour de 0.3 à 0.5 selon les runs, mais les diagnostics 4p restent en alerte avec:
  - `fronts` trop élevé
  - `backbone` trop faible ou marginal
  - `lock` bon
  - `xfer` correct
- L’objectif est d’identifier pourquoi la stratégie 4p ne se convertit pas en victoires stables.

Ce que je veux:
1. Lire l’architecture, la config, la policy, le planner, l’adaptation, le trainer, et les logs fournis.
2. Expliquer, en expert, pourquoi le bot peut sembler bon en 2p mais échoue en 4p.
3. Distinguer:
   - problèmes structurels de la policy/planner
   - problèmes de signal d’entraînement
   - problèmes de sélection / benchmark / promotion
   - problèmes spécifiques au 4p (multi-fronts, overcommit, focus, consolidation, openers, etc.)
4. Dire si les heuristiques 4p actuelles sont cohérentes ou si elles se contredisent.
5. Proposer les 3 causes les plus probables du problème, classées par impact.
6. Proposer un plan d’action concret en ordre de priorité.

Contraintes:
- Sois précis.
- Appuie-toi sur les fichiers et les logs.
- Ne donne pas une réponse vague du type "il faut plus d’entraînement".
- Si tu vois un bug logique, dis-le explicitement.

Tu peux partir de ces indices:
- `lock` a l’air bon
- `fronts` est trop haut
- le 4p est souvent plus faible que le 2p
- les runs récents utilisent des bonus/pénalités pour `front_lock`, `staging_transfer`, `backbone`, `front_pressure`, `guardian`

Réponds en français.
